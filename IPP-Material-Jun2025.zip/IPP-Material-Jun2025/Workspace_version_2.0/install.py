import subprocess
import sys

subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])

subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow"])

try:
    import openpyxl
    print("module 'openpyxl' is installed")
except ModuleNotFoundError:
    print("module 'openpyxl' is not installed")
    print("try running this Python script again")
 
try:
    import requests
    print("module 'requests' is installed")
except ModuleNotFoundError:
    print("module 'requests' is not installed")
    print("try running this Python script again")
 
try:
    import bs4
    print("module 'beautifulsoup4' is installed")
except ModuleNotFoundError:
    print("module 'beautifulsoup4' is not installed")
    print("try running this Python script again")
