import os
from PIL import Image

filename = "img/clungup.jpg"

im = Image.open(filename)
print(type(im))
print ("%s - %s" % (im.size, im.mode))
print(im.size)
# show the image
im.show()

# close the file
im.close()

input("Press Any Key to close the window")
